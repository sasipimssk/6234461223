/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class Letter {
    private String From,To;
    private String line = "";
    public Letter (String From, String To){
        this.From = From;
        this.To = "\n"+To;
        
    }
    public void addline(String line){
        this.line = this.line+"\n"+line;
    }
    public String getText() {
        String Text = "Dear "+From+":"+"\n"+this.line+"\n"+"Sincerely,"+"\n"+To+"\n";
        return Text;
    }
}
