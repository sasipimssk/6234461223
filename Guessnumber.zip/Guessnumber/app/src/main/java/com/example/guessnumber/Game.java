package com.example.guessnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Game extends AppCompatActivity {

        Random ran = new Random();
        int random=ran.nextInt(100)+1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Button check = (Button) findViewById(R.id.check);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            play();
            }
        });
    }
    public void play(){
        TextView help = (TextView) findViewById(R.id.display);
        EditText input = (EditText) findViewById(R.id.guess);
        int guess = Integer.parseInt(input.getText().toString());
        if (guess == random) {
            Intent intent = new Intent(this, Won.class);
            startActivity(intent);
        } else if (guess > random) {
            help.setText("Your guess is too high");
            input.getText().clear();
        } else {
            help.setText("Your guess is too low");
            input.getText().clear();
        }
        }
    }
