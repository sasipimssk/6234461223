/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws FileNotFoundException {
        
        File file = new File("D:\\project\\lab12_1\\src\\lab12_1\\Text.txt");
        PrintWriter output = new PrintWriter(file);
        String input = "";
        int Char = 0,words =0;
        int lineNumber = 0;
        while(!input.equals("quit")){
        Scanner keyboard = new Scanner(System.in);
        input = keyboard.nextLine();
                if(!input.equals("quit")){
                output.println(input);
                lineNumber++;
                continue;
            }
                break;
        }
        output.close();
        Scanner in = new Scanner(file);
        while(in.hasNextLine()==true){
            String Word  = in.nextLine();
            Char+=Word.length();
            if( Word.length()!= 0){
                words++;
            for(int i =0 ; Word.length()>i ; i++){
                if(Word.charAt(i)==' '){
                      words++;
                } 
            }
        }
        }
        System.out.println("Total characters : "+Char);
        System.out.println("Total words : "+words);
        System.out.println("Total lines : "+lineNumber);
        in.close();
       
    }
    
    
}
