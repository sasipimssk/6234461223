/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author ASUS
 */
public class Car {
    private double Gas;
    private double rateGas;
    public Car(double Gas,double rateGas){
         this.Gas = Gas;
         this.rateGas = rateGas;
     }
    public void drive(double distance){
        double usedG = distance/rateGas;
        if(this.Gas<usedG){
            System.out.println("You cannot drive too far , pleaes add gas");
            return;
        }
        this.Gas -= usedG; 
    }
    public void setGas(double amount){
        this.Gas = amount;
    }
    public double getGas(){
        return Gas;
    }
    public double getEfficiency(){
        return rateGas;
    }
    public void addGas(double amount){
        Gas+=amount;
    }
}
