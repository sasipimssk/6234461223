/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author ASUS
 */
public class Truck extends Car{
    private double M_weight;
    private double weight;
    public Truck(double Gas,double rateGas,double M_weight,double weight){
        super(Gas,rateGas);
        this.M_weight = M_weight;
        this.weight = weight;
        if(weight>M_weight){
            this.weight = M_weight;
        }
    }
    @Override
    public void drive(double distance){
      double usedG = distance/getEfficiency();
      if(weight<=10){
          usedG=usedG+((usedG*10/100));
      }else if(weight>=11&&weight<=20){
          usedG=usedG+((usedG*20/100));
      }else{
          usedG=usedG+((usedG*30/100));
      }
      if(getGas()<usedG){
          System.out.println("You cannot drive too far, please add gas");
          return;
      }
      setGas(getGas()-usedG);
    }
}
