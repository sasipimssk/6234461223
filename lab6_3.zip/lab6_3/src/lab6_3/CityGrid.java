/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;

/**
 *
 * @author ASUS
 */
public class CityGrid {
    private int xCoor;
    private int yCoor;
    private int gridSize;
    public int sizeX,sizeY;
    public void getGrid(int lenght,int height){
        sizeX = lenght;
        sizeY = height;
        gridSize = lenght*height;
    }
    public void walk(){
        Random rand = new Random();
        int walkRandom = rand.nextInt(4);
        switch (walkRandom) {
            case 0:
                yCoor+=1;
                break;
            case 1:
                yCoor-=1;
                break;
            case 2:
                xCoor+=1;
                break;
            case 3:
                xCoor-=1;
                break;
            default:
                break;
        }
    }
    public boolean isCity(){
        boolean WALK =false ;
        if(xCoor <= sizeX && xCoor>=0 && yCoor <= sizeY&& yCoor >=0){
            WALK = true;
        }
        return WALK;
    }
   
    public void reset(){
        xCoor = sizeX/2;
        yCoor = sizeY/2;        
    }
}
    

    

