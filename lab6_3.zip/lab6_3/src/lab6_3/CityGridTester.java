/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author ASUS
 */
public class CityGridTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CityGrid test = new CityGrid();
        boolean walking ;
        int turn = 0;
        int maxTurn = 0;
        double averageTurn = 0;
        test.getGrid(10,10);
        test.reset();
        for(int i = 0; i <10000; i++){
           for(int k = 0 ; k <1000 ;k++){
                turn +=1;
                test.walk();
                walking = test.isCity();
                if(walking == false){
                  turn -=1;
                  break;
                }
            }
            averageTurn += turn;
            if(maxTurn<turn)maxTurn = turn;
            turn=0;
            test.reset();
       }
       System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n",averageTurn/10000);
       System.out.println("Maximum number pf the steps that a person can take and is still in the city: "+maxTurn);
    }
    
}
