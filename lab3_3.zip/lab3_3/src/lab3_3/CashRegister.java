/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author ASUS
 */
public class CashRegister {
    public double payment,perchase,goodstax,totaltax ;
   
    public void recordTexablePurchase(double amount,double Tax) {
        double tax = Tax/100;
        goodstax = amount*tax;
        perchase = perchase+amount;
    } 
    public void getTotal(){
       totaltax += goodstax ;
    } 
    public void enterPayment(double Payment){
        payment += Payment;
    
    }

    public double giveChange(){
        double change = payment-(perchase+totaltax);
        perchase = 0;
        payment = 0 ;
        goodstax = 0;
       totaltax = 0;
        return change;
    }
    
}
