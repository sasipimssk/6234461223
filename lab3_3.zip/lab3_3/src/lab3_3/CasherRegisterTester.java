/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author ASUS
 */
public class CasherRegisterTester {
     public static void main(String[] args) {
         CashRegister test = new CashRegister();

         test.enterPayment(100);
         test.recordTexablePurchase(50,0);
         test.recordTexablePurchase(10,0);
         test.recordTexablePurchase(20,7);
         test.getTotal();
        System.out.println("Your change is"+test.giveChange());
     }
}
