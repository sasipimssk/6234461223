/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author usci
 */
public class holleprintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String word = "Hello, World!";
        String word1 = word.replace("e","1");
        String word2 = word1.replace("o","2");
        String word3 = word2.replace('1', 'o');
        String word4 = word3.replace('2', 'e');
        System.out.println(word4);
                
    }
    
}
