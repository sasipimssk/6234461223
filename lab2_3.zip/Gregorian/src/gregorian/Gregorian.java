/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gregorian;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author ASUS
 */
public class Gregorian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.DAY_OF_MONTH,100);
        int dayofMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayofMonth+" "+month+" "+year);
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.AUGUST,10);
        myBirthday.add(Calendar.DAY_OF_MONTH,1000);
        int dayofMonth_m = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month_m = myBirthday.get(Calendar.MONTH);
        int year_m = myBirthday.get(Calendar.YEAR);
        int weekday_m = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(year_m+" "+weekday_m+" "+dayofMonth_m+" "+month_m);
    }
    
}
