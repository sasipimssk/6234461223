/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class ChoiceQuestion extends Question{
    ArrayList<String> Choice = new ArrayList<String>();
    public ChoiceQuestion(String Text){
        super(Text);
    }
    public void addChoice(String ans,Boolean ANS){
        Choice.add(ans);
        if(ANS.equals(true)){
            setAnswer((+Choice.indexOf(ans)+1+""));
        }
    }
    @Override
    public Boolean checkAnswer(String response){
        if(!response.equals(getAnswer())){
            return false;
        }
        return true;
    }
    @Override
    public void display(){
        System.out.println(getText());
        for(int i = 1;i<=Choice.size();i++){
            System.out.println(i+": "+Choice.get(i-1));
        }
    }
}
