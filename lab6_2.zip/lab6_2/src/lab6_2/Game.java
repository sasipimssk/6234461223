/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;

/**
 *
 * @author usci
 */
public class Game {
    public int com ;
    public int you;
    public int uScore,cScore;
    public int uKeep,cKeep;
    public void randomCom() {
    Random rand = new Random();
    int COM = rand.nextInt(3);
    com = COM;
        if (com == 1 ) {
            System.out.println("Computer: PAPER");
        } else if (com == 2) {
            System.out.println("Computer: SCISSORS");
        }else if (com == 0) {
            System.out.println("Computer: ROCK");
        }
    }
    public void Play(int YOU){
        you = YOU;
        int u = 0,c = 0 ;
            if (you ==1&&com==1){
               System.out.println("It's a tie");
            }else if (you ==1&&com==0){
               System.out.println("You win");
               u++;
            }else if (you ==1&&com==2){
               System.out.println("You lose");
               c++;
            }else if (you ==2&&com==2){
               System.out.println("It's a tie");
            }else if (you ==2&&com==1){
               System.out.println("You win");
               u++;
            }else if (you ==2&&com==0){
               System.out.println("You lose");
               c++;
            }else if (you ==0&&com==0){
               System.out.println("It's a tie");
            }else if (you ==0&&com==2){
               System.out.println("You win");
               u++;
            }else if (you ==0&&com==1){
               System.out.println("You lose");
               c++;       
            }
        uScore = u;
        cScore = c;
        }
    public int ckeepScore(){
        cKeep+=cScore;
        cScore=0;
        return cKeep;
    }       
    public int ukeepScore(){
        uKeep+=uScore;
        uScore=0;
        return cKeep;
    }       
    
}
