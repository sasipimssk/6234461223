/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Scanner;


public class RockPaperScissorTester {

    public static void main(String[] args) {
        Game game = new Game();
        Scanner keyboard = new Scanner(System.in);
        int y;
        int u = game.uKeep ,c = game.cKeep ;
        String YOU = null;
        while((u-c) < 2 && (c-u)< 2){
            System.out.print("Enter 0 for ROCK, 1 for PAPER,2 for SCISSORS: ");
                y = keyboard.nextInt();
            do{
                if (y != 1 && y != 2 && y != 0){
                    System.out.print("Enter 0 for ROCK, 1 for PAPER,2 for SCISSORS: ");
                    y = keyboard.nextInt();
                if (y == 1 ) {
                    YOU = "PAPER";
                    System.out.print("You enter : "+YOU+"\n"); 
                    } else if (y == 2) {
                    YOU = "SCISSORS";
                    System.out.print("You enter : "+YOU+"\n"); 
                    }else if (y == 0) {
                    YOU = "ROCK";
                    System.out.print("You enter : "+YOU+"\n"); 
                    }
                }else{
                    if (y == 1 ) {
                    YOU = "PAPER";
                    } else if (y == 2) {
                    YOU = "SCISSORS";
                    }else if (y == 0) {
                    YOU = "ROCK";
                    }
                    System.out.print("You enter : "+YOU+"\n"); 
                    }    
            }while(y != 1 && y != 2 && y != 0);    
            game.randomCom();
            game.Play(y);
            game.ckeepScore();
            game.ukeepScore();
            u = game.uKeep;
            c= game.cKeep;
        }
        System.out.println("------------------------------");
        if(u>c){
            System.out.println("Congrats! You win");
            System.out.println("User Score: "+u);
            System.out.println("Computer Score: "+c);
        }else{
            System.out.println("Too bad! You lose");
            System.out.println("User Score: "+u);
            System.out.println("Computer Score: "+c);
        }
    }
    }
    

