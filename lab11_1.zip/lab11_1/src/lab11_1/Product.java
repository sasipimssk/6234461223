/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Product {
    String goods;
    double amount;
     
    public Product(String goods, int i) {
        this.goods = goods;
        amount = i;
        
    }
    public String getGoods(){
        return goods;
    }
    public double getAmount(){
        return amount;
    }
 
}
