/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class MusicBox implements SimpleQueue  {
    ArrayList<Object> Listsong = new ArrayList<>();

    @Override
    public void enqueue(Object o) {
        Listsong.add(o);
        System.out.println(Listsong.get(0)+" is added in queue");
        
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing "+Listsong.get(0));
        Listsong.remove(0);
    }
    
}
