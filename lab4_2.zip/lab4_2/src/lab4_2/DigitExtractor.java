/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author ASUS
 */
public class DigitExtractor {
    public int number ;
    public DigitExtractor(int anInteger){
        number = anInteger;
     
    }
    public int nextDigit_1(){
        int number_1 = number%10;
        return number_1 ;
     }   
    public int nextDigit_2(){
        int number_2 = (number/10)%10;
        return number_2 ;
     }        
    public int nextDigit_3(){
        int number_3 = (number/100)%10;
        return number_3 ;
     }        
    public int nextDigit_4(){
        int number_4 = (number/1000)%10;
        return number_4 ;
     }        
    public int nextDigit_5(){
        int number_5 = (number/10000)%10;
        return number_5 ;
     }        
}
