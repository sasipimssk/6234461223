/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;

import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author usci
 */
public class IntersectionPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random r = new Random();
        int r1_1 = r.nextInt(51+1);
        int r1_2 = r.nextInt(51+1);
        int r1_3 = r.nextInt(51+1);
        int r1_4 = r.nextInt(51+1);
        Rectangle r1 = new Rectangle(r1_1,r1_2,r1_3,r1_4);
        int r2_1 = r.nextInt(51+1);
        int r2_2 = r.nextInt(51+1);
        int r2_3 = r.nextInt(51+1);
        int r2_4 = r.nextInt(51+1);
        Rectangle r2 = new Rectangle(r2_1,r2_2,r2_3,r2_4);
        System.out.println(r1);
        System.out.println(r2);
        Rectangle r3 = r1.intersection(r2);
        boolean r4 = r3.isEmpty();
        System.out.print("is the intersected rectangle empty?:");
        System.out.println(r4);
    }

    private static void nextInt(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
