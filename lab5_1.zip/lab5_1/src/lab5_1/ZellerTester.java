package lab5_1;
import java.util.Scanner;
public class ZellerTester {
    public static void main(String[] args) {
        Scanner dmy = new Scanner(System.in);
        System.out.print("Enter year (e.g. 2012): ");
        int year = dmy.nextInt();
        System.out.print("Enter month (1-12): ");
        int month = dmy.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int day = dmy.nextInt();
        Zeller dayMonthYear = new Zeller(day,month,year);
        System.out.print("Day of the week is "+dayMonthYear.getDayOfWeek()+"\n");
    }   
}
