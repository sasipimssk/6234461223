/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author ASUS
 */
public class Secretary extends Employee implements Evaluation{
    private int typingSpeed ;
    private int score[];
    public Secretary(String name,int salary,int[] value,int score){
        super(name,salary);
        this.score = value;
        
    }

    @Override
    public double evaluate() {
        double total = 0;
        for(int i =0; i<score.length;i++){
            total+=score[i];
        }
        return total;
    }

    @Override
    public char grade(double total) {
        if(total>90){
            super.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}
