package lab4_3;

public class TimeInterval {
    public int timeBegin ;
    public int timeEnd ;
    public int hourBegin ;
    public int hourEnd ;
    public int hourInterval ;   
    public int minuteBegin ;
    public int minuteEnd ;
    public int minuteInterval ;
    
    public TimeInterval(int timeBegin,int timeEnd) {
        this.timeBegin = timeBegin ;
        this.timeEnd = timeEnd ;
    }
    public void hours() {
        hourBegin = timeBegin/100 ;
        hourEnd = timeEnd/100 ;
        hourInterval = hourEnd - hourBegin ;       
    }
    public void minutes() {
        minuteBegin = timeBegin%100 ;
        minuteEnd = timeEnd%100 ;        
        minuteInterval = minuteEnd - minuteBegin ;
    }
    public int getHours() {
        return hourInterval ;
    }
    public int getMinutes() {
        return Math.abs(minuteInterval) ;
    }
}