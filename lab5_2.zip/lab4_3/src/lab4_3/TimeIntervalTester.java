package lab4_3 ;
import java.util.Scanner ;
public class TimeIntervalTester {
    public static void main(String[] args) {
        Scanner time = new Scanner(System.in) ;
        System.out.print("Enter start time: ") ;
        int timeBegin = time.nextInt() ;
        System.out.print("Enter end time: ") ;
        int timeEnd = time.nextInt() ;
        TimeInterval hour = new TimeInterval(timeBegin,timeEnd) ;
        hour.hours() ;
        hour.minutes() ;
        System.out.println(hour.getHours()+" Hours "+hour.getMinutes()+" Minutes");
    }
}
