/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author ASUS
 */
public class TransactionRecord {
    private int acctNo;
    private double amount ;
    public TransactionRecord(int acctNo,double amount){
        this.amount = amount;
        this.acctNo = acctNo;
    }
    public void setAcctNo(int acctNo){
        this.acctNo = acctNo;
    }
    public int getAcctNo(){
        return acctNo;
    }
    public void setAmount(double amount){
        this.amount = amount;
    }
    public double getAmount(){
        return amount;
    }
}
