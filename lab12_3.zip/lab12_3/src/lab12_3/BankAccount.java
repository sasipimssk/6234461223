/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;



/**
 *
 * @author ASUS
 */
public class BankAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       FileMatch test = new FileMatch();
       test.addTransObject();
       test.addAccountObject();
       test.updateinfo();
       System.out.println("Total Accord : "+test.accoutCnt());
       System.out.println("Total balance : "+test.updateBalance());
       System.out.println("No transaction : "+test.noTrans());
       
    }
    
}
