/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
public class timeInterval {
    public int start,end;
    public void gettime(int time_s,int time_e){
        start = time_s;
        end = time_e;
    }
    public int getHours(){
        int start_hr = start/100;
        int end_hr = end/100;
        int hours = end_hr - start_hr;
        return hours;
   
    }
    public int getMinutes(){
        int start_m = start%100;
        int end_m = end%100;
        int minutes = end_m - start_m ;
        return minutes;
    }
}
